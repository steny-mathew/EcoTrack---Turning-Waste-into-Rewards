"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Gift, ShoppingBag, Coffee, TreePine, Sparkles } from "lucide-react"

const rewardCategories = [
  {
    icon: Gift,
    title: "Eco Products",
    description: "Sustainable goods from partner brands",
    points: "50-500 points",
    color: "bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400",
    hoverColor: "group-hover:bg-green-200 dark:group-hover:bg-green-800/30",
    examples: ["Bamboo products", "Organic clothing", "Solar gadgets"],
  },
  {
    icon: ShoppingBag,
    title: "Store Discounts",
    description: "Savings at eco-friendly retailers",
    points: "25-200 points",
    color: "bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400",
    hoverColor: "group-hover:bg-blue-200 dark:group-hover:bg-blue-800/30",
    examples: ["Whole Foods", "Patagonia", "Local co-ops"],
  },
  {
    icon: Coffee,
    title: "Local Experiences",
    description: "Coffee shops, restaurants, and services",
    points: "100-300 points",
    color: "bg-amber-100 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400",
    hoverColor: "group-hover:bg-amber-200 dark:group-hover:bg-amber-800/30",
    examples: ["Coffee shops", "Farm-to-table", "Bike rentals"],
  },
  {
    icon: TreePine,
    title: "Carbon Offsets",
    description: "Direct environmental impact projects",
    points: "75-1000 points",
    color: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400",
    hoverColor: "group-hover:bg-emerald-200 dark:group-hover:bg-emerald-800/30",
    examples: ["Tree planting", "Clean energy", "Ocean cleanup"],
  },
]

export function RewardsSection() {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null)

  return (
    <section id="rewards" className="py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="relative inline-block">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance hover:text-primary transition-colors duration-300 cursor-default">
              Earn While You Help the Planet
            </h2>
            <Sparkles className="absolute -top-2 -right-8 w-6 h-6 text-primary animate-pulse" />
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
            Every sustainable action earns EcoPoints. Redeem them for rewards that align with your values.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {rewardCategories.map((category, index) => (
            <Card
              key={index}
              className="border-border/50 hover:border-primary/50 hover:shadow-2xl hover:scale-105 transition-all duration-300 cursor-pointer group relative overflow-hidden"
              onMouseEnter={() => setHoveredCard(index)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <CardHeader>
                <div
                  className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 transition-all duration-300 ${category.color} ${category.hoverColor}`}
                >
                  <category.icon className="w-6 h-6 group-hover:scale-110 group-hover:rotate-3 transition-all duration-200" />
                </div>
                <CardTitle className="text-lg text-foreground group-hover:text-primary transition-colors duration-200">
                  {category.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm mb-3 group-hover:text-foreground transition-colors duration-200">
                  {category.description}
                </p>
                <Badge
                  variant="secondary"
                  className="text-xs mb-3 group-hover:bg-primary/10 transition-colors duration-200"
                >
                  {category.points}
                </Badge>

                <div
                  className={`transition-all duration-300 overflow-hidden ${hoveredCard === index ? "max-h-20 opacity-100" : "max-h-0 opacity-0"}`}
                >
                  <div className="text-xs text-muted-foreground space-y-1 pt-2 border-t border-border/50">
                    {category.examples.map((example, i) => (
                      <div key={i} className="flex items-center gap-1">
                        <div className="w-1 h-1 bg-primary rounded-full"></div>
                        <span>{example}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-8 md:p-12 hover:from-primary/20 hover:to-accent/20 transition-all duration-500 group relative overflow-hidden">
          <div className="absolute inset-0 opacity-5 group-hover:opacity-10 transition-opacity duration-500">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(34,197,94,0.3),transparent_50%)] animate-pulse"></div>
          </div>

          <div className="max-w-3xl mx-auto text-center relative z-10">
            <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4 text-balance group-hover:text-primary transition-colors duration-300">
              Ready to Start Earning Rewards?
            </h3>
            <p className="text-lg text-muted-foreground mb-8 text-balance group-hover:text-foreground transition-colors duration-300">
              Join our community of eco-warriors and start turning your sustainable actions into meaningful rewards
              today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 hover:scale-105 hover:shadow-lg transition-all duration-200 group"
              >
                <Gift className="mr-2 h-4 w-4 group-hover:animate-bounce" />
                Browse Rewards
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="hover:scale-105 hover:shadow-lg transition-all duration-200 bg-transparent"
              >
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
