"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AnimatedCounter } from "./animated-counter"
import { TrendingUp, Users, Recycle, DollarSign } from "lucide-react"
import { ScrollReveal } from "./scroll-reveal"

const stats = [
  {
    value: 1250,
    label: "Tons of Waste Diverted",
    suffix: "",
    prefix: "",
    icon: Recycle,
    description: "Total waste diverted from landfills through our platform",
  },
  {
    value: 847,
    label: "Active Users",
    suffix: "+",
    prefix: "",
    icon: Users,
    description: "Growing community of eco-conscious individuals",
  },
  {
    value: 73,
    label: "Recycling Rate Improvement",
    suffix: "%",
    prefix: "",
    icon: TrendingUp,
    description: "Average improvement in user recycling habits",
  },
  {
    value: 15400,
    label: "Rewards Distributed",
    suffix: "",
    prefix: "$",
    icon: DollarSign,
    description: "Total value of rewards given to our users",
  },
]

export function ImpactSection() {
  const [hoveredStat, setHoveredStat] = useState<number | null>(null)

  return (
    <section id="impact" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-full h-full">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute bg-primary rounded-full animate-float"
              style={{
                width: `${Math.random() * 10 + 5}px`,
                height: `${Math.random() * 10 + 5}px`,
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 10}s`,
                animationDuration: `${Math.random() * 5 + 5}s`,
              }}
            />
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <ScrollReveal className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance hover:text-primary transition-colors duration-300 cursor-default animate-shimmer">
            Real Impact, Real Results
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance animate-slide-up">
            Join thousands of users who are already making a difference. See the collective impact we're creating
            together.
          </p>
        </ScrollReveal>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <ScrollReveal key={index} delay={index * 150} direction="up">
              <Card
                className="text-center border-border/50 hover-lift hover-glow transition-all duration-300 cursor-pointer group relative overflow-hidden animate-bounce-in"
                style={{ animationDelay: `${index * 150}ms` }}
                onMouseEnter={() => setHoveredStat(index)}
                onMouseLeave={() => setHoveredStat(null)}
              >
                <div className="absolute top-4 right-4 opacity-10 group-hover:opacity-20 transition-opacity duration-300 animate-rotate-3d">
                  <stat.icon className="w-8 h-8 text-primary" />
                </div>

                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                <CardContent className="pt-6 relative z-10">
                  <div className="mb-2">
                    <AnimatedCounter end={stat.value} suffix={stat.suffix} prefix={stat.prefix} />
                  </div>
                  <p className="text-sm text-muted-foreground font-medium group-hover:text-foreground transition-colors">
                    {stat.label}
                  </p>

                  {hoveredStat === index && (
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-popover text-popover-foreground text-xs rounded-lg shadow-lg border animate-bounce-in">
                      {stat.description}
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-popover"></div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </ScrollReveal>
          ))}
        </div>

        <ScrollReveal delay={600}>
          <div className="bg-primary/5 rounded-2xl p-8 md:p-12 text-center hover:bg-primary/10 transition-colors duration-300 group relative overflow-hidden animate-fade-in-scale">
            <div className="absolute inset-0 animated-gradient opacity-20 group-hover:opacity-30 transition-opacity duration-300" />

            <div className="relative z-10">
              <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4 text-balance group-hover:text-primary transition-colors duration-300 animate-shimmer">
                Turn Your Metal Waste Into Revenue
              </h3>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto text-balance group-hover:text-foreground transition-colors duration-300">
                Our advanced AI identifies valuable metals in your waste stream, connecting you with certified recycling
                partners for maximum returns.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="bg-primary hover:bg-primary/90 hover-lift hover-glow transition-all duration-200 group animate-bounce-in"
                >
                  Start Tracking Impact
                  <TrendingUp className="ml-2 h-4 w-4 group-hover:rotate-12 transition-transform" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="hover-lift transition-all duration-200 bg-transparent animate-bounce-in"
                  style={{ animationDelay: "0.2s" }}
                >
                  View Success Stories
                </Button>
              </div>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  )
}
