export function EcoLogo({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <div className={`${className} relative`}>
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M16 2C16 2 8 6 8 16C8 22.6274 13.3726 28 20 28C26.6274 28 32 22.6274 32 16C32 6 24 2 24 2C24 2 20 8 16 8C12 8 8 2 8 2"
          fill="url(#gradient)"
        />
        <circle cx="20" cy="18" r="4" fill="#4ade80" />
        <defs>
          <linearGradient id="gradient" x1="8" y1="2" x2="32" y2="28" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22c55e" />
            <stop offset="1" stopColor="#16a34a" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  )
}
