"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Recycle, Award, TrendingUp, Users, Leaf, Coins } from "lucide-react"
import { InteractivePopup } from "./interactive-popup"
import { ScrollReveal } from "./scroll-reveal"

const features = [
  {
    icon: Recycle,
    title: "Smart Waste Tracking",
    description:
      "Scan and log your recyclables with our AI-powered recognition system. Every item counts towards your environmental impact.",
    details: [
      "AI-powered waste recognition",
      "Barcode scanning for products",
      "Automatic categorization",
      "Progress tracking dashboard",
    ],
  },
  {
    icon: Award,
    title: "Instant Rewards",
    description:
      "Earn EcoPoints for every sustainable action. Redeem for discounts, products, and exclusive eco-friendly experiences.",
    details: [
      "Points for every eco-action",
      "Tiered reward system",
      "Partner store discounts",
      "Exclusive eco-products",
    ],
  },
  {
    icon: TrendingUp,
    title: "Impact Analytics",
    description:
      "Visualize your environmental footprint reduction with detailed charts and progress tracking over time.",
    details: [
      "Real-time impact metrics",
      "Monthly progress reports",
      "Goal setting and tracking",
      "Comparative analytics",
    ],
  },
  {
    icon: Users,
    title: "Community Challenges",
    description: "Join local groups and compete in sustainability challenges. Make a bigger impact together.",
    details: [
      "Local community groups",
      "Weekly eco-challenges",
      "Leaderboards and rankings",
      "Team collaboration tools",
    ],
  },
  {
    icon: Leaf,
    title: "Carbon Offset Tracking",
    description: "Monitor your carbon footprint reduction and contribute to verified offset projects worldwide.",
    details: [
      "Carbon footprint calculator",
      "Verified offset projects",
      "Impact visualization",
      "Contribution tracking",
    ],
  },
  {
    icon: Coins,
    title: "Marketplace Integration",
    description: "Connect with local recycling centers and eco-friendly businesses for seamless reward redemption.",
    details: [
      "Local business partnerships",
      "Recycling center locations",
      "Reward redemption system",
      "Eco-product marketplace",
    ],
  },
]

export function FeaturesSection() {
  const [activePopup, setActivePopup] = useState<number | null>(null)

  return (
    <section id="features" className="py-24 bg-muted/30 relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div
          className="absolute top-10 left-10 w-32 h-32 bg-primary rounded-full animate-float"
          style={{ animationDelay: "0s" }}
        />
        <div
          className="absolute top-40 right-20 w-24 h-24 bg-accent rounded-full animate-float"
          style={{ animationDelay: "2s" }}
        />
        <div
          className="absolute bottom-20 left-1/4 w-20 h-20 bg-primary rounded-full animate-float"
          style={{ animationDelay: "4s" }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <ScrollReveal className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance hover:text-primary transition-colors duration-300 cursor-default animate-shimmer">
            Transform Your Environmental Impact
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance animate-slide-up">
            Discover how EcoTrack makes sustainable living rewarding, measurable, and engaging for everyone.
          </p>
        </ScrollReveal>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <ScrollReveal key={index} delay={index * 100} direction="up">
              <Card
                className="border-border/50 hover-lift hover-glow transition-all duration-300 cursor-pointer group animate-fade-in-scale relative overflow-hidden"
                style={{ animationDelay: `${index * 100}ms` }}
                onClick={() => setActivePopup(index)}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" />

                <CardHeader className="relative z-10">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary/20 group-hover:scale-110 transition-all duration-300 animate-pulse-glow">
                    <feature.icon className="w-6 h-6 text-primary group-hover:scale-110 transition-transform duration-200" />
                  </div>
                  <CardTitle className="text-xl text-foreground group-hover:text-primary transition-colors duration-200">
                    {feature.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="relative z-10">
                  <p className="text-muted-foreground leading-relaxed group-hover:text-foreground transition-colors duration-200">
                    {feature.description}
                  </p>
                  <div className="mt-4 text-xs text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-200 animate-bounce-in">
                    Click to explore features →
                  </div>
                </CardContent>
              </Card>
            </ScrollReveal>
          ))}
        </div>
      </div>

      {/* Interactive Popups */}
      {features.map((feature, index) => (
        <InteractivePopup
          key={index}
          isOpen={activePopup === index}
          onClose={() => setActivePopup(null)}
          title={feature.title}
          description={feature.description}
          icon={<feature.icon className="w-6 h-6 text-primary" />}
          details={feature.details}
        />
      ))}
    </section>
  )
}
