"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { EcoLogo } from "./eco-logo"
import { Menu, X } from "lucide-react"
import Link from "next/link"

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <nav
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/95 backdrop-blur-md border-b border-border shadow-lg"
          : "bg-background/80 backdrop-blur-md border-b border-border/50"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="group-hover:scale-110 group-hover:rotate-3 transition-all duration-200">
              <EcoLogo />
            </div>
            <span className="text-xl font-bold text-primary group-hover:text-primary/80 transition-colors">
              EcoTrack
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <a
              href="#features"
              className="text-muted-foreground hover:text-primary transition-all duration-200 relative group"
            >
              Features
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-200 group-hover:w-full"></span>
            </a>
            <a
              href="#impact"
              className="text-muted-foreground hover:text-primary transition-all duration-200 relative group"
            >
              Impact
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-200 group-hover:w-full"></span>
            </a>
            <a
              href="#rewards"
              className="text-muted-foreground hover:text-primary transition-all duration-200 relative group"
            >
              Rewards
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-200 group-hover:w-full"></span>
            </a>
            <a
              href="#about"
              className="text-muted-foreground hover:text-primary transition-all duration-200 relative group"
            >
              About
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-200 group-hover:w-full"></span>
            </a>

            <Link href="/login">
              <Button
                variant="outline"
                size="sm"
                className="hover:scale-105 hover:shadow-md transition-all duration-200 bg-transparent"
              >
                Log In
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button size="sm" className="hover:scale-105 hover:shadow-md transition-all duration-200">
                Dashboard
              </Button>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(!isOpen)}
              className="hover:scale-110 transition-transform duration-200"
            >
              {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        <div
          className={`md:hidden transition-all duration-300 overflow-hidden ${
            isOpen ? "max-h-64 opacity-100" : "max-h-0 opacity-0"
          }`}
        >
          <div className="py-4 border-t border-border">
            <div className="flex flex-col gap-4">
              <a
                href="#features"
                className="text-muted-foreground hover:text-primary transition-colors duration-200 hover:translate-x-2 transform"
                onClick={() => setIsOpen(false)}
              >
                Features
              </a>
              <a
                href="#impact"
                className="text-muted-foreground hover:text-primary transition-colors duration-200 hover:translate-x-2 transform"
                onClick={() => setIsOpen(false)}
              >
                Impact
              </a>
              <a
                href="#rewards"
                className="text-muted-foreground hover:text-primary transition-colors duration-200 hover:translate-x-2 transform"
                onClick={() => setIsOpen(false)}
              >
                Rewards
              </a>
              <a
                href="#about"
                className="text-muted-foreground hover:text-primary transition-colors duration-200 hover:translate-x-2 transform"
                onClick={() => setIsOpen(false)}
              >
                About
              </a>
              <div className="flex gap-2 pt-2">
                <Link href="/login" className="flex-1">
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full bg-transparent hover:scale-105 transition-transform duration-200"
                  >
                    Log In
                  </Button>
                </Link>
                <Link href="/dashboard" className="flex-1">
                  <Button size="sm" className="w-full hover:scale-105 transition-transform duration-200">
                    Dashboard
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}
