"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowRight, Leaf, Recycle, Award } from "lucide-react"
import Link from "next/link"
import { InteractivePopup } from "./interactive-popup"
import { FloatingParticles } from "./floating-particles"
import { ScrollReveal } from "./scroll-reveal"

const cardData = [
  {
    icon: <Recycle className="h-6 w-6 text-primary" />,
    title: "Track Waste",
    description: "Monitor your recycling and waste reduction efforts with smart tracking tools.",
    details: [
      "AI-powered waste recognition",
      "Real-time tracking dashboard",
      "Weekly progress reports",
      "Smart recycling reminders",
    ],
  },
  {
    icon: <Award className="h-6 w-6 text-accent" />,
    title: "Earn Rewards",
    description: "Get points and unlock rewards for every sustainable action you take.",
    details: [
      "EcoPoints for every action",
      "Exclusive eco-friendly products",
      "Local business discounts",
      "Carbon offset contributions",
    ],
  },
  {
    icon: <Leaf className="h-6 w-6 text-primary" />,
    title: "Save Planet",
    description: "Make a real environmental impact with data-driven sustainability insights.",
    details: [
      "Carbon footprint reduction",
      "Community impact metrics",
      "Environmental goal setting",
      "Global sustainability tracking",
    ],
  },
]

export function HeroSection() {
  const [activePopup, setActivePopup] = useState<number | null>(null)

  return (
    <section className="min-h-screen relative flex items-center justify-center overflow-hidden">
      <FloatingParticles />

      <div className="absolute inset-0 animated-gradient opacity-10" />
      <div className="absolute inset-0 grid-pattern" />

      {/* Content */}
      <div className="relative z-10 w-full max-w-6xl mx-auto px-4 py-20">
        <ScrollReveal className="text-center mb-16">
          <h1 className="text-6xl md:text-8xl font-bold text-foreground mb-6 text-balance hover:scale-105 transition-transform duration-300 cursor-default animate-fade-in-scale">
            Turn your{" "}
            <span className="text-primary hover:text-primary/80 transition-colors animate-pulse-glow">waste</span>
            <br />
            into <span className="text-accent hover:text-accent/80 transition-colors animate-shimmer">rewards</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-3xl mx-auto text-balance animate-slide-up">
            Transform your environmental impact into meaningful rewards. Track, reduce, and earn with sustainable
            living.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
            <Link href="/login">
              <Button
                size="lg"
                className="h-14 px-8 text-lg hover-lift hover-glow transition-all duration-200 group animate-bounce-in"
              >
                Get Started
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link href="#features">
              <Button
                variant="outline"
                size="lg"
                className="h-14 px-8 text-lg bg-transparent hover-lift transition-all duration-200 animate-bounce-in"
                style={{ animationDelay: "0.2s" }}
              >
                Learn More
              </Button>
            </Link>
          </div>
        </ScrollReveal>

        <ScrollReveal delay={300} className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {cardData.map((card, index) => (
            <Card
              key={index}
              className="p-6 bg-card/50 backdrop-blur-sm border-border/50 hover-lift hover-glow transition-all duration-300 cursor-pointer group animate-float"
              style={{ animationDelay: `${index * 0.5}s` }}
              onClick={() => setActivePopup(index)}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 group-hover:scale-110 hover-rotate transition-all duration-200 animate-rotate-3d">
                  {card.icon}
                </div>
                <h3 className="font-semibold text-lg group-hover:text-primary transition-colors">{card.title}</h3>
              </div>
              <p className="text-muted-foreground group-hover:text-foreground transition-colors">{card.description}</p>
              <div className="mt-4 text-xs text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                Click to learn more →
              </div>
            </Card>
          ))}
        </ScrollReveal>
      </div>

      {/* Interactive Popups */}
      {cardData.map((card, index) => (
        <InteractivePopup
          key={index}
          isOpen={activePopup === index}
          onClose={() => setActivePopup(null)}
          title={card.title}
          description={card.description}
          icon={card.icon}
          details={card.details}
        />
      ))}
    </section>
  )
}
