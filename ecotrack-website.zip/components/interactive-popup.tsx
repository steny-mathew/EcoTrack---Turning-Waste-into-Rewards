"use client"

import type React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { X, ArrowRight } from "lucide-react"

interface PopupProps {
  isOpen: boolean
  onClose: () => void
  title: string
  description: string
  icon: React.ReactNode
  details: string[]
}

export function InteractivePopup({ isOpen, onClose, title, description, icon, details }: PopupProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200"
        onClick={onClose}
      />

      {/* Popup */}
      <Card className="relative w-full max-w-md animate-in zoom-in-95 duration-200 shadow-2xl border-2">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">{icon}</div>
              <CardTitle className="text-xl">{title}</CardTitle>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0 hover:bg-destructive/10 hover:text-destructive"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">{description}</p>
          <div className="space-y-2">
            {details.map((detail, index) => (
              <div key={index} className="flex items-center gap-2 text-sm">
                <ArrowRight className="h-3 w-3 text-primary" />
                <span>{detail}</span>
              </div>
            ))}
          </div>
          <Button onClick={onClose} className="w-full mt-4">
            Got it!
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
