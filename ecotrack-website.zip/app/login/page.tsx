import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { EcoLogo } from "@/components/eco-logo"
import Link from "next/link"

export default function LoginPage() {
  return (
    <div className="min-h-screen relative flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('/images/forest-background.jpg')",
        }}
      />
      <div className="absolute inset-0 forest-overlay" />

      {/* Content */}
      <div className="relative z-10 w-full max-w-md mx-auto px-4">
        <Card className="p-8 bg-white/90 backdrop-blur-sm border-0 shadow-2xl">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <EcoLogo className="w-16 h-16" />
            </div>
            <h1 className="text-2xl font-bold text-primary mb-2">EcoTrack</h1>
            <h2 className="text-lg font-semibold text-foreground mb-1 text-balance">Turn Waste into Rewards.</h2>
            <p className="text-lg font-semibold text-foreground text-balance">Save the Planet.</p>
          </div>

          <div className="space-y-4">
            <Input type="email" placeholder="Email" className="h-12 bg-white/80 border-border/50" />
            <Input type="password" placeholder="Password" className="h-12 bg-white/80 border-border/50" />
            <Link href="/dashboard">
              <Button className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-medium">
                Log In
              </Button>
            </Link>
          </div>

          <div className="text-center my-6">
            <span className="text-muted-foreground text-sm">OR</span>
          </div>

          <Link href="/dashboard">
            <Button variant="ghost" className="w-full text-muted-foreground hover:text-foreground">
              Continue as Guest
            </Button>
          </Link>

          <div className="flex justify-center gap-4 mt-8 text-xs text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors">
              Terms of Service
            </a>
            <span>|</span>
            <a href="#" className="hover:text-foreground transition-colors">
              Privacy Policy
            </a>
          </div>
        </Card>
      </div>
    </div>
  )
}
